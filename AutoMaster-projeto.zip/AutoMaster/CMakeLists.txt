cmake_minimum_required(VERSION 3.22)
project(AutoMaster VERSION 1.0.0)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded")   # sem precisar do VC++ Redistributable

if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/JUCE/CMakeLists.txt")
    add_subdirectory(JUCE)
else()
    include(FetchContent)
    FetchContent_Declare(JUCE GIT_REPOSITORY https://github.com/juce-framework/JUCE.git GIT_TAG 8.0.8 GIT_SHALLOW TRUE)
    FetchContent_MakeAvailable(JUCE)
endif()

juce_add_plugin(AutoMaster
    COMPANY_NAME "AutoMaster"
    PLUGIN_MANUFACTURER_CODE Amst
    PLUGIN_CODE Amas
    FORMATS VST3
    PRODUCT_NAME "AutoMaster"
    VST3_CATEGORIES Fx Dynamics Mastering
    IS_SYNTH FALSE NEEDS_MIDI_INPUT FALSE NEEDS_MIDI_OUTPUT FALSE
    COPY_PLUGIN_AFTER_BUILD FALSE)
target_sources(AutoMaster PRIVATE Source/PluginProcessor.cpp Source/PluginEditor.cpp)
target_compile_definitions(AutoMaster PUBLIC
    JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0 JUCE_VST3_CAN_REPLACE_VST2=0 JUCE_DISPLAY_SPLASH_SCREEN=0)
target_link_libraries(AutoMaster PRIVATE juce::juce_audio_utils
    PUBLIC juce::juce_recommended_config_flags)
