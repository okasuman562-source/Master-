#include "../Source/AutoMasterDSP.h"
#include <cstdio>
#include <random>
int main(){
  const double fs=44100; am::AutoMaster m; m.prepare(fs);
  am::Params p; p.targetLufs=-11; p.ceilingDb=-1;
  std::mt19937 rng(1); std::normal_distribution<float> nd(0,1);
  // sinal: graves fortes + ruído + kicks, bem baixo (~ -24 dBFS)
  const int N=(int)(fs*40); const int B=512; std::vector<float> L(B),R(B);
  float peak=0; double e=0; long cnt=0; float lp=0;
  for(int s0=0;s0<N;s0+=B){
    for(int i=0;i<B;i++){ int t=s0+i; float tt=t/fs;
      float kick=std::exp(-fmodf(tt,0.5f)*18.f)*std::sin(2*3.14159f*55*tt)*0.5f;
      lp=0.98f*lp+0.02f*nd(rng); float noise=lp*0.6f+nd(rng)*0.02f;
      L[i]=0.1f*(kick+noise+0.3f*std::sin(2*3.14159f*440*tt)); R[i]=0.1f*(kick+noise*0.8f+0.3f*std::sin(2*3.14159f*660*tt)); }
    m.process(L.data(),R.data(),B,p);
    if(s0>fs*30) for(int i=0;i<B;i++){ peak=std::max(peak,std::max(fabsf(L[i]),fabsf(R[i]))); e+= (double)L[i]*L[i]+R[i]*R[i]; cnt++; }
    if((s0/B)%100==0) printf("t=%5.1fs lufs=%6.2f makeup=%5.2f dB GR=%4.2f\n",s0/fs,m.meterLufs.load(),m.meterGainDb.load(),m.meterReductionDb.load());
  }
  printf("pico final: %.2f dBFS (teto -1.0)  nan? %d\n",20*log10(peak), std::isnan(peak));
}
