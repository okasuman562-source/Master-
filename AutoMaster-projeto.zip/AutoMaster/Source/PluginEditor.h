#pragma once
#include "PluginProcessor.h"

class AutoMasterEditor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit AutoMasterEditor (AutoMasterProcessor&);
    void paint (juce::Graphics&) override;
    void resized() override;
private:
    void timerCallback() override { repaint (0, 270, getWidth(), 120); }
    AutoMasterProcessor& proc;
    struct Knob { juce::Slider s; juce::Label l; std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> a; };
    Knob knobs[6];
    juce::ToggleButton bypass { "Bypass" };
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> bypassA;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (AutoMasterEditor)
};
