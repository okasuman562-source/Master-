#include "PluginProcessor.h"
#include "PluginEditor.h"

using APVTS = juce::AudioProcessorValueTreeState;

APVTS::ParameterLayout AutoMasterProcessor::createLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;
    p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { "target", 1 }, "Loudness Alvo",
                 juce::NormalisableRange<float> (-20.f, -5.f, 0.1f), -11.f, juce::AudioParameterFloatAttributes().withLabel ("LUFS")));
    p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { "eq", 1 }, "Auto EQ",
                 juce::NormalisableRange<float> (0.f, 100.f, 1.f), 60.f, juce::AudioParameterFloatAttributes().withLabel ("%")));
    p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { "glue", 1 }, "Cola",
                 juce::NormalisableRange<float> (0.f, 100.f, 1.f), 50.f, juce::AudioParameterFloatAttributes().withLabel ("%")));
    p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { "width", 1 }, "Largura",
                 juce::NormalisableRange<float> (0.f, 150.f, 1.f), 100.f, juce::AudioParameterFloatAttributes().withLabel ("%")));
    p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { "tone", 1 }, "Tom",
                 juce::NormalisableRange<float> (-3.f, 3.f, 0.1f), 0.f, juce::AudioParameterFloatAttributes().withLabel ("dB")));
    p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { "ceiling", 1 }, "Teto",
                 juce::NormalisableRange<float> (-3.f, -0.1f, 0.1f), -1.f, juce::AudioParameterFloatAttributes().withLabel ("dBFS")));
    p.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { "bypass", 1 }, "Bypass", false));
    return { p.begin(), p.end() };
}

AutoMasterProcessor::AutoMasterProcessor()
    : AudioProcessor (BusesProperties().withInput ("Input", juce::AudioChannelSet::stereo(), true)
                                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "STATE", createLayout()) {}

void AutoMasterProcessor::prepareToPlay (double sr, int)
{
    dsp.prepare (sr);
    setLatencySamples (dsp.getLatency());
}

void AutoMasterProcessor::processBlock (juce::AudioBuffer<float>& buf, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    if (buf.getNumChannels() < 2) return;

    am::Params p;
    p.targetLufs = *apvts.getRawParameterValue ("target");
    p.eqAmount   = *apvts.getRawParameterValue ("eq") * 0.01f;
    p.glue       = *apvts.getRawParameterValue ("glue") * 0.01f;
    p.width      = *apvts.getRawParameterValue ("width") * 0.01f;
    p.tone       = *apvts.getRawParameterValue ("tone");
    p.ceilingDb  = *apvts.getRawParameterValue ("ceiling");
    p.bypass     = *apvts.getRawParameterValue ("bypass") > 0.5f;
    dsp.process (buf.getWritePointer (0), buf.getWritePointer (1), buf.getNumSamples(), p);
}

juce::AudioProcessorEditor* AutoMasterProcessor::createEditor() { return new AutoMasterEditor (*this); }

void AutoMasterProcessor::getStateInformation (juce::MemoryBlock& d)
{
    if (auto xml = apvts.copyState().createXml()) copyXmlToBinary (*xml, d);
}
void AutoMasterProcessor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
        if (xml->hasTagName (apvts.state.getType())) apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new AutoMasterProcessor(); }
