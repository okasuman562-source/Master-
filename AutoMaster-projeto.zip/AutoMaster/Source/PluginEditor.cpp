#include "PluginEditor.h"

static const juce::Colour kBg (0xff14161c), kAccent (0xff3ddc97), kPanel (0xff1e222b);

AutoMasterEditor::AutoMasterEditor (AutoMasterProcessor& p) : AudioProcessorEditor (&p), proc (p)
{
    const char* ids[6]   = { "target", "eq", "glue", "width", "tone", "ceiling" };
    const char* names[6] = { "LOUDNESS", "AUTO EQ", "COLA", "LARGURA", "TOM", "TETO" };
    for (int i = 0; i < 6; ++i)
    {
        auto& k = knobs[i];
        k.s.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
        k.s.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 80, 20);
        k.s.setColour (juce::Slider::rotarySliderFillColourId, kAccent);
        k.s.setColour (juce::Slider::thumbColourId, juce::Colours::white);
        k.s.setColour (juce::Slider::textBoxTextColourId, juce::Colours::white);
        k.s.setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
        k.l.setText (names[i], juce::dontSendNotification);
        k.l.setJustificationType (juce::Justification::centred);
        k.l.setColour (juce::Label::textColourId, juce::Colours::lightgrey);
        k.l.setFont (juce::FontOptions (13.0f, juce::Font::bold));
        addAndMakeVisible (k.s); addAndMakeVisible (k.l);
        k.a = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (proc.apvts, ids[i], k.s);
    }
    bypass.setColour (juce::ToggleButton::textColourId, juce::Colours::white);
    bypass.setColour (juce::ToggleButton::tickColourId, kAccent);
    addAndMakeVisible (bypass);
    bypassA = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (proc.apvts, "bypass", bypass);
    setSize (640, 400);
    startTimerHz (15);
}

void AutoMasterEditor::paint (juce::Graphics& g)
{
    g.fillAll (kBg);
    g.setColour (kAccent);
    g.setFont (juce::FontOptions (26.0f, juce::Font::bold));
    g.drawText ("AutoMaster", 24, 14, 300, 34, juce::Justification::left);
    g.setColour (juce::Colours::grey);
    g.setFont (juce::FontOptions (13.0f));
    g.drawText ("Masterização automática - coloque no Master e dê play na música", 24, 46, 520, 20, juce::Justification::left);

    g.setColour (kPanel);
    g.fillRoundedRectangle (20.f, 278.f, (float) getWidth() - 40.f, 104.f, 10.f);
    auto lufs = proc.dsp.meterLufs.load(), gain = proc.dsp.meterGainDb.load(), gr = proc.dsp.meterReductionDb.load();
    g.setColour (juce::Colours::white);
    g.setFont (juce::FontOptions (15.0f, juce::Font::bold));
    juce::String t1 = "Loudness atual: " + (lufs < -60.f ? juce::String ("--") : juce::String (lufs, 1)) + " LUFS";
    g.drawText (t1, 40, 288, 280, 24, juce::Justification::left);
    g.drawText ("Ganho automatico: " + juce::String (gain, 1) + " dB", 330, 288, 280, 24, juce::Justification::left);
    g.setColour (juce::Colours::lightgrey);
    g.setFont (juce::FontOptions (13.0f));
    g.drawText ("Reducao do limiter: " + juce::String (gr, 1) + " dB", 40, 316, 280, 20, juce::Justification::left);
    // barra de loudness em relação ao alvo
    const float target = *proc.apvts.getRawParameterValue ("target");
    const float x0 = 40.f, w = (float) getWidth() - 80.f, y = 350.f;
    g.setColour (juce::Colour (0xff2c313d)); g.fillRoundedRectangle (x0, y, w, 10.f, 5.f);
    const float pos = juce::jlimit (0.f, 1.f, (lufs + 30.f) / 30.f);
    g.setColour (kAccent); g.fillRoundedRectangle (x0, y, w * pos, 10.f, 5.f);
    const float tx = x0 + w * juce::jlimit (0.f, 1.f, (target + 30.f) / 30.f);
    g.setColour (juce::Colours::white); g.fillRect (tx - 1.f, y - 4.f, 2.f, 18.f);
}

void AutoMasterEditor::resized()
{
    const int w = getWidth() / 3;
    for (int i = 0; i < 6; ++i)
    {
        const int cx = (i % 3) * w, cy = 78 + (i / 3) * 92;
        knobs[i].l.setBounds (cx, cy, w, 16);
        knobs[i].s.setBounds (cx + 25, cy + 14, w - 50, 80);
    }
    bypass.setBounds (getWidth() - 110, 18, 90, 24);
}
