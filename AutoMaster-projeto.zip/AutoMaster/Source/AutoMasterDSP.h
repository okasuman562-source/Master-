// AutoMasterDSP.h - núcleo de DSP independente do JUCE (testável em qualquer plataforma)
#pragma once
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <vector>

namespace am
{
constexpr double kPi = 3.14159265358979323846;
inline float dbToLin (float db) { return std::pow (10.0f, db * 0.05f); }
inline float linToDb (float lin) { return 20.0f * std::log10 (std::max (lin, 1.0e-9f)); }

// ---------------------------------------------------------------- Biquad (RBJ)
struct Biquad
{
    double b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0;
    double z1 = 0, z2 = 0;

    void reset() { z1 = z2 = 0; }
    inline float process (float x)
    {
        const double in = x;
        const double out = b0 * in + z1;
        z1 = b1 * in - a1 * out + z2;
        z2 = b2 * in - a2 * out;
        return (float) out;
    }
    void set (double nb0, double nb1, double nb2, double a0, double na1, double na2)
    {
        b0 = nb0 / a0; b1 = nb1 / a0; b2 = nb2 / a0; a1 = na1 / a0; a2 = na2 / a0;
    }
    void makePeak (double fs, double f, double q, double gainDb)
    {
        const double A = std::pow (10.0, gainDb / 40.0), w = 2 * kPi * f / fs;
        const double al = std::sin (w) / (2 * q), c = std::cos (w);
        set (1 + al * A, -2 * c, 1 - al * A, 1 + al / A, -2 * c, 1 - al / A);
    }
    void makeLowShelf (double fs, double f, double gainDb, double q = 0.7071)
    {
        const double A = std::pow (10.0, gainDb / 40.0), w = 2 * kPi * f / fs;
        const double al = std::sin (w) / (2 * q), c = std::cos (w), s = 2 * std::sqrt (A) * al;
        set (A * ((A + 1) - (A - 1) * c + s), 2 * A * ((A - 1) - (A + 1) * c), A * ((A + 1) - (A - 1) * c - s),
             (A + 1) + (A - 1) * c + s, -2 * ((A - 1) + (A + 1) * c), (A + 1) + (A - 1) * c - s);
    }
    void makeHighShelf (double fs, double f, double gainDb, double q = 0.7071)
    {
        const double A = std::pow (10.0, gainDb / 40.0), w = 2 * kPi * f / fs;
        const double al = std::sin (w) / (2 * q), c = std::cos (w), s = 2 * std::sqrt (A) * al;
        set (A * ((A + 1) + (A - 1) * c + s), -2 * A * ((A - 1) + (A + 1) * c), A * ((A + 1) + (A - 1) * c - s),
             (A + 1) - (A - 1) * c + s, 2 * ((A - 1) - (A + 1) * c), (A + 1) - (A - 1) * c - s);
    }
    void makeHighPass (double fs, double f, double q = 0.7071)
    {
        const double w = 2 * kPi * f / fs, al = std::sin (w) / (2 * q), c = std::cos (w);
        set ((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al);
    }
    void makeBandPass (double fs, double f, double q)   // ganho de pico 0 dB
    {
        const double w = 2 * kPi * f / fs, al = std::sin (w) / (2 * q), c = std::cos (w);
        set (al, 0, -al, 1 + al, -2 * c, 1 - al);
    }
};

// Filtro K-weighting (ITU-R BS.1770) para medir loudness
struct KWeight
{
    Biquad shelf, hp;
    void prepare (double fs)
    {
        // Coeficientes derivados do BS.1770 para qualquer taxa de amostragem
        {
            const double G = 3.999843853973347, Q = 0.7071752369554196, fc = 1681.974450955533;
            const double K = std::tan (kPi * fc / fs), Vh = std::pow (10.0, G / 20.0), Vb = std::pow (Vh, 0.4996667741545416);
            const double a0 = 1 + K / Q + K * K;
            shelf.b0 = (Vh + Vb * K / Q + K * K) / a0;
            shelf.b1 = 2 * (K * K - Vh) / a0;
            shelf.b2 = (Vh - Vb * K / Q + K * K) / a0;
            shelf.a1 = 2 * (K * K - 1) / a0;
            shelf.a2 = (1 - K / Q + K * K) / a0;
        }
        {
            const double Q = 0.5003270373238773, fc = 38.13547087602444;
            const double K = std::tan (kPi * fc / fs);
            const double a0 = 1 + K / Q + K * K;
            hp.b0 = 1 / a0; hp.b1 = -2 / a0; hp.b2 = 1 / a0;
            hp.a1 = 2 * (K * K - 1) / a0;
            hp.a2 = (1 - K / Q + K * K) / a0;
        }
        shelf.reset(); hp.reset();
    }
    inline float process (float x) { return hp.process (shelf.process (x)); }
};

// ---------------------------------------------------------------- Parâmetros
struct Params
{
    float targetLufs = -11.0f;  // loudness alvo
    float eqAmount   = 0.6f;    // 0..1 intensidade do Auto-EQ
    float glue       = 0.5f;    // 0..1 compressão de cola
    float width      = 1.0f;    // 0..1.5 largura estéreo
    float tone       = 0.0f;    // -3..+3 dB (negativo=quente, positivo=brilhante)
    float ceilingDb  = -1.0f;   // teto do limiter
    bool  bypass     = false;
};

// ---------------------------------------------------------------- Masterizador
class AutoMaster
{
public:
    static constexpr int kBands = 9;
    static constexpr float kFreq[kBands]   = { 62.5f, 125.f, 250.f, 500.f, 1000.f, 2000.f, 4000.f, 8000.f, 14000.f };
    // Curva alvo (dB relativos à média), típica de uma master moderna: graves cheios, agudos suaves
    static constexpr float kTarget[kBands] = { 3.0f, 3.5f, 2.0f, 0.5f, -0.5f, -1.5f, -3.0f, -5.0f, -8.0f };

    void prepare (double sampleRate)
    {
        fs = sampleRate;
        lookahead = std::max (8, (int) std::round (0.003 * fs));
        for (auto& v : { &delayL, &delayR, &dryL, &dryR })
            v->assign ((size_t) lookahead, 0.0f);
        reqRing.assign ((size_t) lookahead, 1.0f);
        boxRing.assign ((size_t) lookahead, 1.0f);
        reset();

        for (int b = 0; b < kBands; ++b)
            for (int c = 0; c < 2; ++c)
                bandFilt[b][c].makeBandPass (fs, kFreq[b], 1.41);
        for (int c = 0; c < 2; ++c) { kw[c].prepare (fs); }
        for (int c = 0; c < 2; ++c) subHp[c].makeHighPass (fs, 25.0, 0.7071);
        sideHp.makeHighPass (fs, 120.0, 0.7071);
        updateEq (true);
    }
    int getLatency() const { return lookahead - 1; }

    void reset()
    {
        std::fill (delayL.begin(), delayL.end(), 0.f); std::fill (delayR.begin(), delayR.end(), 0.f);
        std::fill (dryL.begin(), dryL.end(), 0.f);     std::fill (dryR.begin(), dryR.end(), 0.f);
        std::fill (reqRing.begin(), reqRing.end(), 1.f); std::fill (boxRing.begin(), boxRing.end(), 1.f);
        wp = rp = 0; boxSum = (double) lookahead; relGain = 1.0;
        for (auto& b : bandPow) b = 0; for (auto& g : bandGainDb) g = 0;
        compEnv = 0; levelAvg = 1.0e-4; compGainDb = 0;
        msMomentary = 0; msShort = 0; makeupDb = 0; gateOpenSamples = 0;
        for (auto& r : bandFilt) for (auto& f : r) f.reset();
        for (auto& f : eq) for (auto& g : f) g.reset();
        for (auto& f : subHp) f.reset(); sideHp.reset();
        for (auto& f : kw) { f.shelf.reset(); f.hp.reset(); }
        for (auto& f : kwOut) { f.shelf.reset(); f.hp.reset(); }
    }

    // Leituras para a interface
    std::atomic<float> meterLufs { -70.0f }, meterGainDb { 0.0f }, meterReductionDb { 0.0f };

    void process (float* L, float* R, int n, const Params& p)
    {
        const int block = n;
        // --- (1) Análise espectral (sobre o sinal de entrada, mid)
        double energyIn = 0;
        for (int i = 0; i < n; ++i)
        {
            const float m = 0.5f * (L[i] + R[i]);
            energyIn += (double) m * m;
            for (int b = 0; b < kBands; ++b)
            {
                const float y = bandFilt[b][0].process (m);
                bandAcc[b] += (double) y * y;
            }
        }
        {
            const double rmsDb = 10.0 * std::log10 (energyIn / std::max (1, n) + 1e-12);
            const bool audible = rmsDb > -55.0;
            const double a = std::exp (-(double) block / (fs * 4.0));   // ~4 s
            if (audible)
                for (int b = 0; b < kBands; ++b)
                    bandPow[b] = a * bandPow[b] + (1.0 - a) * (bandAcc[b] / std::max (1, n));
            for (auto& v : bandAcc) v = 0;
        }
        updateEq (false, p);

        double sumGr = 0; float minGain = 1.f;
        const float ceilLin = dbToLin (p.ceilingDb - 0.3f);   // margem para true-peak
        const float makeupLin = dbToLin (makeupDb);
        const double attC = std::exp (-1.0 / (fs * 0.030)), relC = std::exp (-1.0 / (fs * 0.220));
        const double limRelC = std::exp (-1.0 / (fs * 0.080));
        const double avgC = std::exp (-1.0 / (fs * 5.0));
        const float ratio = 1.5f + 1.5f * p.glue;
        const float kneeDb = 6.0f;

        for (int i = 0; i < n; ++i)
        {
            const float dryInL = L[i], dryInR = R[i];

            // --- (2) EQ: HPF 25 Hz + Auto-EQ + tilt
            float l = subHp[0].process (L[i]), r = subHp[1].process (R[i]);
            for (int b = 0; b < kBands + 2; ++b) { l = eq[b][0].process (l); r = eq[b][1].process (r); }

            // --- (3) Compressor de cola (linkado, threshold automático)
            const float peakIn = std::max (std::fabs (l), std::fabs (r));
            const double pk2 = (double) peakIn * peakIn;
            compEnv = pk2 > compEnv ? attC * compEnv + (1 - attC) * pk2 : relC * compEnv + (1 - relC) * pk2;
            levelAvg = avgC * levelAvg + (1.0 - avgC) * std::max (compEnv, 1e-10);
            const float envDb = 10.0f * std::log10 ((float) compEnv + 1e-12f);
            const float thr = 10.0f * std::log10 ((float) levelAvg + 1e-12f) - 1.0f - 4.0f * p.glue;
            const float over = envDb - thr;
            float reduce = 0;
            if (2 * over < -kneeDb) reduce = 0;
            else if (2 * std::fabs (over) <= kneeDb)
                reduce = (1 - 1 / ratio) * (over + kneeDb / 2) * (over + kneeDb / 2) / (2 * kneeDb);
            else reduce = (1 - 1 / ratio) * over;
            if (envDb < -60.f) reduce = 0;
            const float cg = dbToLin (-reduce * (p.glue > 0.001f ? 1.f : 0.f));
            l *= cg; r *= cg;
            compGainDb = -reduce;

            // --- (4) Largura estéreo (graves sempre mono)
            float mid = 0.5f * (l + r), side = 0.5f * (l - r);
            side = sideHp.process (side) * p.width;
            l = mid + side; r = mid - side;

            // --- (5) Ganho automático para atingir o loudness alvo
            l *= makeupLin; r *= makeupLin;

            // --- (6) Limiter lookahead (brickwall)
            const float pk = std::max (std::fabs (l), std::fabs (r));
            const float req = pk > ceilLin ? ceilLin / pk : 1.0f;
            // mínimo deslizante em N amostras
            reqRing[(size_t) wp] = req;
            float m = 1.0f;
            for (int k = 0; k < lookahead; ++k) m = std::min (m, reqRing[(size_t) k]);
            // release suave
            relGain = (m < relGain) ? (double) m : relGain + ((double) m - relGain) * (1.0 - limRelC);
            const float rg = (float) std::min (relGain, (double) m + 0.0 * 1.0);
            const float rgc = std::min (rg, 1.0f);
            // boxcar sobre N amostras
            boxSum += (double) rgc - (double) boxRing[(size_t) wp];
            boxRing[(size_t) wp] = rgc;
            const float g = (float) (boxSum / lookahead);
            wp = (wp + 1) % lookahead;

            // atraso do sinal
            delayL[(size_t) dpos] = l; delayR[(size_t) dpos] = r;
            dryL[(size_t) dpos] = dryInL; dryR[(size_t) dpos] = dryInR;
            const int rpos = (dpos + 1) % lookahead;   // amostra mais antiga
            float outL = delayL[(size_t) rpos] * g, outR = delayR[(size_t) rpos] * g;
            // rede de segurança final
            outL = std::max (-ceilLin, std::min (ceilLin, outL));
            outR = std::max (-ceilLin, std::min (ceilLin, outR));
            const float dL = dryL[(size_t) rpos], dR = dryR[(size_t) rpos];
            dpos = (dpos + 1) % lookahead;

            minGain = std::min (minGain, g);
            sumGr += g;

            // medição de loudness na saída (K-weighted)
            const float kl = kwOut[0].process (outL), kr = kwOut[1].process (outR);
            const double e = (double) kl * kl + (double) kr * kr;
            const double cm = std::exp (-1.0 / (fs * 0.4));
            msMomentary = cm * msMomentary + (1 - cm) * e;
            const double cs = std::exp (-1.0 / (fs * 3.0));
            if (msMomentary > 1.0e-6 * 1.0)   // gate ~ -60 LUFS
                msShort = cs * msShort + (1 - cs) * e;

            L[i] = p.bypass ? dL : outL;
            R[i] = p.bypass ? dR : outR;
        }

        // Atualiza ganho de makeup (feedback lento, até 3 dB/s)
        const float lufsShort = (float) (-0.691 + 10.0 * std::log10 (msShort + 1e-12));
        const float lufsMom = (float) (-0.691 + 10.0 * std::log10 (msMomentary + 1e-12));
        if (lufsMom > -50.0f && msShort > 1e-9)
        {
            const float err = p.targetLufs - lufsShort;
            const float maxStep = (std::fabs (p.targetLufs - lufsShort) > 4.0f ? 8.0f : 3.0f) * (float) block / (float) fs;
            makeupDb += std::max (-maxStep, std::min (maxStep, err * 0.5f * (float) block / (float) fs * 2.0f));
            makeupDb = std::max (-12.0f, std::min (30.0f, makeupDb));
        }
        meterLufs.store (lufsShort);
        meterGainDb.store (makeupDb);
        meterReductionDb.store (-linToDb (minGain));
    }

private:
    double fs = 44100;
    int lookahead = 132;

    // Auto-EQ
    Biquad bandFilt[kBands][2];
    double bandPow[kBands] {}, bandAcc[kBands] {};
    float  bandGainDb[kBands] {};
    Biquad eq[kBands + 2][2];
    Biquad subHp[2], sideHp;
    float lastTone = 999.f;

    void updateEq (bool force, const Params& p = Params())
    {
        // média das bandas em dB
        float dB[kBands]; float mean = 0;
        double total = 0; for (auto v : bandPow) total += v;
        const bool have = total > 1e-12;
        for (int b = 0; b < kBands; ++b) { dB[b] = 10.f * std::log10 ((float) bandPow[b] + 1e-12f); mean += dB[b]; }
        mean /= kBands;
        const float step = 0.5f * (float) 0.01;   // evolução lenta por bloco
        for (int b = 0; b < kBands; ++b)
        {
            float wanted = 0;
            if (have)
            {
                const float dev = dB[b] - mean - kTarget[b];
                wanted = std::max (-4.0f, std::min (4.0f, -dev * 0.7f * p.eqAmount));
            }
            const float d = wanted - bandGainDb[b];
            bandGainDb[b] += std::max (-step, std::min (step, d));
            if (force) bandGainDb[b] = 0;
            for (int c = 0; c < 2; ++c) eq[b][c].makePeak (fs, kFreq[b], 0.9, bandGainDb[b]);
        }
        for (int c = 0; c < 2; ++c)
        {
            eq[kBands][c].makeLowShelf (fs, 150.0, -p.tone * 0.5);
            eq[kBands + 1][c].makeHighShelf (fs, 5000.0, p.tone * 0.7);
        }
        lastTone = p.tone;
    }

    // Loudness / makeup
    KWeight kw[2], kwOut[2];
    double msMomentary = 0, msShort = 0;
    float makeupDb = 0; int gateOpenSamples = 0;

    // Compressor
    double compEnv = 0, levelAvg = 1e-4; float compGainDb = 0;

    // Limiter
    std::vector<float> delayL, delayR, dryL, dryR, reqRing, boxRing;
    int wp = 0, rp = 0, dpos = 0; double boxSum = 0, relGain = 1.0;
};
}
