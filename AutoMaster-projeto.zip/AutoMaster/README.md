# AutoMaster — masterização automática (VST3) para FL Studio

Coloque no **Master** do FL Studio e dê play na música: o plugin ouve o que passa e ajusta sozinho.

Cadeia: HPF 25 Hz → Auto-EQ (9 bandas, aprende o espectro da música) → compressor de cola
(threshold automático) → largura estéreo (graves sempre mono) → ganho automático até o
LUFS alvo → limiter lookahead (teto em dBFS).

Controles: Loudness alvo, Auto EQ, Cola, Largura, Tom, Teto, Bypass.
Latência: ~3 ms (informada ao FL, que compensa automaticamente).

## Como gerar o instalador (sem instalar nada)
1. Crie um repositório no GitHub e envie esta pasta.
2. Aba **Actions** > "Build AutoMaster (Windows)" > Run workflow.
3. Em ~10 min baixe o artefato **AutoMaster-Windows**: `AutoMaster-Instalador.exe` e `AutoMaster-VST3.zip`.

## Instalar
Rode `AutoMaster-Instalador.exe` (ou copie `AutoMaster.vst3` para `C:\Program Files\Common Files\VST3`).
No FL Studio: Options > Manage plugins > Find installed plugins.

## Teste do DSP (qualquer PC com g++)
`g++ -O2 -std=c++17 tests/test_dsp.cpp -o t && ./t`
