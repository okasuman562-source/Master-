[Setup]
AppName=AutoMaster
AppVersion=1.0.0
AppPublisher=AutoMaster
DefaultDirName={commoncf64}\VST3
DisableDirPage=yes
DisableProgramGroupPage=yes
Uninstallable=yes
CreateUninstallRegKey=yes
UninstallFilesDir={commoncf64}\VST3\AutoMaster-uninstall
OutputDir=..\dist
OutputBaseFilename=AutoMaster-Instalador
ArchitecturesInstallIn64BitMode=x64compatible
ArchitecturesAllowed=x64compatible
PrivilegesRequired=admin
Compression=lzma2
SolidCompression=yes
WizardStyle=modern

[Languages]
Name: "pt"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Files]
Source: "..\build\AutoMaster_artefacts\Release\VST3\AutoMaster.vst3\*"; DestDir: "{commoncf64}\VST3\AutoMaster.vst3"; Flags: recursesubdirs ignoreversion

[Messages]
pt.FinishedLabel=AutoMaster instalado em C:\Program Files\Common Files\VST3.%nNo FL Studio: Options > Manage plugins > Find installed plugins.
